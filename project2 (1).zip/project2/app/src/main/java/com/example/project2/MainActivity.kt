package com.example.project2
import android.content.ClipData
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var listView: ListView
    private lateinit var addItemButton: Button
    private lateinit var nameEditText: EditText
    private lateinit var priceEditText: EditText
    private lateinit var urlEditText: EditText
    private lateinit var adapter: ArrayAdapter<String>
    private val items = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        listView = findViewById(R.id.list_view)
        addItemButton = findViewById(R.id.add_item_button)
        nameEditText = findViewById(R.id.name_edit_text)
        priceEditText = findViewById(R.id.price_edit_text)
        urlEditText = findViewById(R.id.url_edit_text)


        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items)
        listView.adapter = adapter

        addItemButton.setOnClickListener {
            val name = nameEditText.text.toString()
            val price = priceEditText.text.toString()
            val url = urlEditText.text.toString()
            val item = "$name - $price - $url"
            items.add(item)
            adapter.notifyDataSetChanged()
        }
        /*listView.setOnScrollListener(object : AbsListView.OnScrollListener {
            override fun onScroll(view: AbsListView, firstVisibleItem: Int, visibleItemCount: Int, totalItemCount: Int) {
                if (firstVisibleItem + visibleItemCount >= totalItemCount) {
                    // End of the screen reached. Add a new item to the list
                    val name = nameEditText.text.toString()
                    val price = priceEditText.text.toString().toFloat()
                    val url = urlEditText.text.toString()
                    val item = "$name - $price - $url"
                   // val item = ClipData.Item(name, price, url)
                    items.add(item)
                    adapter.notifyDataSetChanged()
                }
            }

            override fun onScrollStateChanged(view: AbsListView, scrollState: Int) {}
        })*/

    }

}
